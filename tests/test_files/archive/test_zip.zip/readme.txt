This is a test ZIP file
